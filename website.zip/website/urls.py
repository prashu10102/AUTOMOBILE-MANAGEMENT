"""website URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from signup.views import signaction
from login.views import loginaction
from login.views import welcome
from login.views import vehicle1,vehicle2,vehicle3,vehicle4,vehicle5,vehicle6,welcome2,addtocart,payment,payment2,payment3,payment4,payment5,payment6,payment7,payment8

urlpatterns = [
    path('admin/', admin.site.urls),
    path('signup/',signaction),
    path('login/',loginaction),
    path('',welcome,name='welcome'),
    path('vehicle1/',vehicle1,name='vehicle1'),
    path('vehicle2/',vehicle2,name='vehicle2'),
    path('vehicle3/',vehicle3,name='vehicle3'),
    path('vehicle4/',vehicle4,name='vehicle4'),
    path('vehicle5/',vehicle5,name='vehicle5'),
    path('vehicle6/',vehicle6,name='vehicle6'),
    path('welcome2/',welcome2,name='welcome2'),
    path('addtocart/',addtocart,name='addtocart'),
    path('payment/',payment,name='payment'),
    path('payment2/',payment2,name='payment2'),
    path('payment3/',payment3,name='payment3'),
    path('payment4/',payment4,name='payment4'),
    path('payment5/',payment5,name='payment5'),
    path('payment6/',payment6,name='payment6'),
    path('payment7/',payment7,name='payment7'),
    path('payment8/',payment8,name='payment8'),
]
