from django.shortcuts import render
import mysql.connector as sql
em=''
pwd=''
# Create your views here.
def loginaction(request):
    global em,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",passwd="prashu10102",database='website')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
          
            if key=="email":
                em=value
            if key=="password":
                pwd=value
        
        c="select * from users where email='{}' and password='{}'".format(em,pwd)
        cursor.execute(c)
        t=tuple(cursor.fetchall())
        if t==():
            return render(request,'error.html')
        else:
            return render(request,"welcome2.html")

    return render(request,'login_page.html')

def welcome(request):
    return render(request,'welcome.html')

def vehicle1(request):
    return render(request,'vehicle1.html')

def vehicle2(request):
    return render(request,'vehicle2.html')
def vehicle3(request):
    return render(request,'vehicle3.html')
def vehicle4(request):
    return render(request,'vehicle4.html')
def vehicle5(request):
    return render(request,'vehicle5.html')
def vehicle6(request):
    return render(request,'vehicle6.html')
def welcome2(request):
    return render(request,'welcome2.html')
def addtocart(request):
    return render(request,'addtocart.html')
def payment(request):
    return render(request,'payment.html')
def payment2(request):
    return render(request,'payment2.html')
def payment3(request):
    return render(request,'payment3.html')
def payment4(request):
    return render(request,'payment4.html')
def payment5(request):
    return render(request,'payment5.html')
def payment6(request):
    return render(request,'payment6.html')
def payment7(request):
    return render(request,'payment7.html')
def payment8(request):
    return render(request,'payment8.html')